export class CreateTempDto {}
